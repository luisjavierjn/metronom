package com.metronom.ttt.app.exceptions;

public class GameException extends Exception {

    public GameException(String message) {
        super(message);
    }
}

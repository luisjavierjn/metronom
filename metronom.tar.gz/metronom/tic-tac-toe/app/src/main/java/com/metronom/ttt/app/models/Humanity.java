package com.metronom.ttt.app.models;

public interface Humanity {
    boolean isHuman();
}

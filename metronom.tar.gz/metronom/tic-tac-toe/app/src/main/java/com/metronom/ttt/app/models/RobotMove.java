package com.metronom.ttt.app.models;

public interface RobotMove {

    int calculateMove(Board board);
}
